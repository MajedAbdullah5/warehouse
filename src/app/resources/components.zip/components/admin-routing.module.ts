import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CompanySettingsComponent } from './company-settings/company-settings.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FrmValidationComponent } from './frm-validation/frm-validation.component';
import { TblDatatableComponent } from './tbl-datatable/tbl-datatable.component';

const routes: Routes = [
  {
    path: 'dashboard', component: DashboardComponent,
    data: {
      title: 'Dashboard',
      icon: 'fa fa-home',
      caption: '',
      status: true
    },
  },
  { path: 'frm-validation', component: FrmValidationComponent},
  { path: 'data-table', component: TblDatatableComponent },
  {
    path: 'company-settings',
    component: CompanySettingsComponent,
    data: {
      title: 'Company Settings',
      icon: 'fa fa-cogs',
      caption: '',
      status: true
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AdminRoutingModule { }
