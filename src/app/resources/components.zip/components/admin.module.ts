import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {DataTablesModule} from 'angular-datatables';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AdminRoutingModule } from './admin-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CompanySettingsComponent } from './company-settings/company-settings.component';
import { AdminComponent } from './admin.component';


@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule,
    DataTablesModule,
    FormsModule
  ],
  declarations: [
    DashboardComponent,
    CompanySettingsComponent,
    AdminComponent
  ]
})
export class AdminModule { }
